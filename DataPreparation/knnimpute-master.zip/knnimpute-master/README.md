[![Build Status](https://travis-ci.org/hammerlab/knnimpute.svg?branch=master)](https://travis-ci.org/hammerlab/knnimpute) [![Coverage Status](https://coveralls.io/repos/github/hammerlab/knnimpute/badge.svg?branch=master)](https://coveralls.io/github/hammerlab/knnimpute?branch=master)

# knnimpute
Multiple implementations of kNN imputation in pure Python + NumPy